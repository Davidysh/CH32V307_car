#ifndef TIME_H_O
#define TIME_H_O

void time_begin();

void time_end();

int get_time();

#endif