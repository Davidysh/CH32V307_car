#ifndef KEY_FN_H_
#define KEY_FN_H_

void key_fn(unsigned char key_value);

#endif