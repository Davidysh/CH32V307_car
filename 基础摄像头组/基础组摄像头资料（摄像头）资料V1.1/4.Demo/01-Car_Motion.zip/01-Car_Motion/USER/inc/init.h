#ifndef INIT_H_
#define INIT_H_

void init();

#endif